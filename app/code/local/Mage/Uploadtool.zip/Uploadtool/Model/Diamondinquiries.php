<?php
class Mage_Uploadtool_Model_Diamondinquiries extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {  
    	parent::_construct();
        $this->_init('uploadtool/diamondinquiries');
    }  
}