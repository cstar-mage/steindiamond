<?php
class Mage_Uploadtool_Model_Mysql4_Diamondinquiries extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {  
        $this->_init('uploadtool/diamondinquiries', 'id');
    }  
}